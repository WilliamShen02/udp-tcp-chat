/**
 * Author: Weilong Shen
 * GTID: 903628514
 * GT Email: wshen61@gatech.edu
 */

#pragma once

int main(int argc, char *argv[]);
